package generateData;

import java.util.ArrayList;
import java.io.BufferedWriter; 
import java.io.File; 
import java.io.FileNotFoundException; 

import java.io.FileWriter; 
import java.io.IOException; 
import java.util.List;
import java.util.Random;
public class CreateTrans {
	private float randomFloat(int min, int max) {
		Random random = new Random();
		float r = random.nextFloat() * max;
		while (r < min) {
			r = random.nextFloat() * max;
		}
		return r;
	}
	
	private int randomInt(int min, int max) {
		Random random = new Random();
		int r = random.nextInt(max)%(max-min+1) + min;
		return r;
	}
	
	public String RandomString(int length) {  
	    String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";  
	    Random random = new Random();  
	    StringBuffer buf = new StringBuffer();  
	    for (int i = 0; i < length; i++) {  
	        int num = random.nextInt(52);  
	        buf.append(str.charAt(num));  
	    }  
	    return buf.toString();  
	} 
	
	public void createTrans () {
		int n = 5000000;
		List<Object[]> l = new ArrayList<>();
		File csv = new File("C:/Users/SONY/Desktop/Transaction.csv");
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(csv, true));
			for (int i = 0; i < n; i++) {
				transactions trans = new transactions(i + 1, randomInt(1,50000) , randomFloat(10, 1000), randomInt(1,10), RandomString(randomInt(20, 50)));
				String[] s = {String.valueOf(trans.getTransId()), String.valueOf(trans.getCustId())
								, String.valueOf(trans.getTransTotal()), String.valueOf(trans.getTransNumItems()), trans.getTransDesc()};
				bw.write(s[0].toString() + "," 
						+s[1].toString() + ","
						+s[2].toString() + ","
						+s[3].toString() + ","
						+s[4].toString());
				bw.newLine();
			}
			bw.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
