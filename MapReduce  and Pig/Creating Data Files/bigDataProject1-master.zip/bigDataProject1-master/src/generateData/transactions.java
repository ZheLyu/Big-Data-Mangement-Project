package generateData;

public class transactions {
	private int transId;
	private int custId;
	private float transTotal;
	private int transNumItems;
	private String transDesc;
	public transactions(int _transId, int _custId, float _transTotal, int _transNumItems, String _transDesc) {
		this.transId = _transId;
		this.custId = _custId;
		this.transTotal = _transTotal;
		this.transNumItems = _transNumItems;
		this.transDesc = _transDesc;
		
	}
	
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public float getTransTotal() {
		return transTotal;
	}
	public void setTransTotal(float transTotal) {
		this.transTotal = transTotal;
	}
	public int getTransNumItems() {
		return transNumItems;
	}
	public void setTransNumItems(int transNumItems) {
		this.transNumItems = transNumItems;
	}
	public String getTransDesc() {
		return transDesc;
	}
	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}
	

}
