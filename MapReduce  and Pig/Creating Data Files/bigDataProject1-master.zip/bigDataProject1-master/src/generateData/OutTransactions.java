package generateData;

import java.util.List;
import java.io.BufferedWriter; 
import java.io.File; 
import java.io.FileNotFoundException; 

import java.io.FileWriter; 
import java.io.IOException; 
public class OutTransactions {
	public static void main(String[] args) throws IOException {
		CreateTrans c = new CreateTrans();
		c.createTrans();
	}
}
