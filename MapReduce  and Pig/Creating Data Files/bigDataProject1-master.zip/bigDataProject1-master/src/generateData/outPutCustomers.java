package generateData;

import java.util.ArrayList;
import java.io.File;
import java.util.List;

public class outPutCustomers {
	public static List<String> customers;
	static Object[] cc;

	
	public static  void outPutCustomerss(){
	  customers=new ArrayList<String>();
	}
	
	public static void generateCustomers(){
		for(int i=0;i<50000;i++){
		generateData.customers ncustomers=new customers(i+1);
		customers.add(ncustomers.returnall());
		
		}
		cc = customers.toArray();
	}
	
	
	public static void main(String[] args) {
		    outPutCustomerss();
		    generateCustomers();
	        boolean isSuccess=CSVUtils.exportCsv(new File("D:/Big Data/customers.csv"), customers);
	        System.out.println(isSuccess);
		
	
		
	}
}
