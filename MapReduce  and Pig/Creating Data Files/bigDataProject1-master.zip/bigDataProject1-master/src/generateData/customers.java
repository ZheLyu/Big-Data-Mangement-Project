package generateData;

import java.util.Random;

public class customers {
	
   private int Id=1;
   private String name;
   private int age;
   private int countryCode;
   private float salary;
	   
	
   public customers(int Id){
	  this.Id=Id;
	  setAge();
	  setCountryCode();
	  setSalary();
	  setName();
	  
	   
   }
   public int getId() {
	   
		return Id;
	}
   public void setId(){
	   if(Id<=50000){
		   Id=Id+1;
	   }
   }
	
	public String getName() {
		return name;
	}
	
	public int getAge() {
		
		return age;
	}
	public void setAge() {
		this.age=(int) (Math.random()*60+10);
		
	}
	public int getCountryCode() {
		return countryCode;
	}
	public void setCountryCode() {
		this.countryCode = (int) (Math.random()*10)+1;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary() {
		float temsalary=(float)(Math.random()*10000);
		while(temsalary<100){
			temsalary=(float)(Math.random()*10000);
		}
	   this.salary=temsalary;
	    
	}
	public  void setName() {
	    String base = "abcdefghijklmnopqrstuvwxyz0123456789";   
	    Random random = new Random();
	    int length=(int)( Math.random()*10+10);
	    StringBuffer sb = new StringBuffer();   
	    for (int i = 0; i < length; i++) {   
	        int number = random.nextInt(base.length());   
	        sb.append(base.charAt(number));   
	    }   
	   this.name=sb.toString();   
	 }  
    public String returnall(){
    	return String.valueOf(getId())+","+name+","+String.valueOf(getAge())+","+String.valueOf(getCountryCode())+","+String.valueOf(getSalary());
    }
}
